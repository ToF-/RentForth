\ Tests.fs  gforth Tests.fs

INCLUDE TestQSort.fs
INCLUDE TestRent.fs

TESTS-QSORT
TESTS-RENT
." Success "
.S
BYE
