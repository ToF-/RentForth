include Rent.fs
initialize 
1 5 10 add-order 
3 7 14 add-order 
5 9  7 add-order 
6 9  8 add-order 
10 4 7 add-order 
max-value ?

initialize 
39 10 319 add-order 
53 2 687 add-order 
68 7 183 add-order 
87 2 579 add-order 
99 3 116 add-order 
max-value ?
bye
\ if the last order update a time < start of this order, update cur-value with last-upde
