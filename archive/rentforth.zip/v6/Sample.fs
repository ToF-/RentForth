REQUIRE Rent.fs
initialize
39 10 319 add-order
53  2 687 add-order
68  7 183 add-order
87  2 579 add-order
99  3 116 add-order
compute-value
rent-value ? bye
